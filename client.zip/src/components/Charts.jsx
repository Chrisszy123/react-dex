import React from 'react'

const Charts = () => {
  return (
    <div>Charts</div>
  )
}

export default Charts