import React from 'react'

const OpenOrders = () => {
  return (
    <div>OpenOrders</div>
  )
}

export default OpenOrders