import React from 'react'

const Trade = () => {
  return (
    <div>Trade</div>
  )
}

export default Trade